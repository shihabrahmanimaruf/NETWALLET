<?php

namespace App\Http\Controllers;

use App\Recivegetway;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.admin-dashboard');
    }

    public function showAllUser()
    {
        $alluser = User::all();
        return view('admin.user-list')->with(compact('alluser'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return $id;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function BuyRateManage()
    {
        $getway = Recivegetway::all();
        return view('admin.buyratemanage')->with(compact('getway'));
    }

    public function BuyRateManageShow($id)
    {
        $getwaybyid = Recivegetway::find($id);
        return view('admin.buyratemanageedit')->with(compact('getwaybyid'));
    }

    public function BuyRateManageUpdate(Request $request)
    {
        $id = $request->id;
        $getway = Recivegetway::find($id);
        $getway->name = $request->name;
        $getway->buy_rate = $request->buy_rate;
        $getway->save();
        Session::flash('flash_message', 'Buy Rate Update successfully!');
        return redirect()->route('admin.buyratemanage');
    }

    public function SellRateManage()
    {
        $getway = Recivegetway::all();
        return view('admin.sellratemanage')->with(compact('getway'));
    }

    public function SellRateManageShow($id)
    {
        $getwaybyid = Recivegetway::find($id);
        return view('admin.sellratemanageedit')->with(compact('getwaybyid'));
    }

    public function SellRateManageUpdate(Request $request)
    {
        $id = $request->id;
        $getway = Recivegetway::find($id);
        $getway->name = $request->name;
        $getway->sell_rate = $request->sell_rate;
        $getway->save();
        Session::flash('flash_message', 'Sell Rate Update successfully!');
        return redirect()->route('admin.sellratemanage');
    }
}
