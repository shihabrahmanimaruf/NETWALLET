$(function () {
    function myFunction() {
        var x = document.getElementById("title");
        x.value = x.value.toUpperCase();
    }

}); /**
 * Created by EXPERT SOFT IT on 9/30/2017.
 */
