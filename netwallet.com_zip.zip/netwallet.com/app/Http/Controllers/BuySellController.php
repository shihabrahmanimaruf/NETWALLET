<?php

namespace App\Http\Controllers;

use App\Recivegetway;
use App\Sendgetway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class BuySellController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function showBuyForm(Request $request){

        $request->all();

        $buyFrom = Sendgetway::all();
        $buyTo = Recivegetway::all();

        return view('netwallet.buy')->with(compact('buyFrom'))->with(compact('buyTo'));
    }

    public function showSellForm(){
        $sellTo = Sendgetway::all();
        $sellFrom = Recivegetway::all();
        return view('netwallet.sell')->with(compact('sellTo'))->with(compact('sellFrom'));
    }
    public function showExchangeForm(){
        $exchange = Recivegetway::all();
        return view('netwallet.exchange')->with(compact('exchange'));
    }
}
